define({
  "name": "Enpublic",
  "version": "1.0.0",
  "description": "Enpublic ITU Grad Project API documentation",
  "url": "http://enpublic.mkytr.com/api",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-06-10T07:23:02.990Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
